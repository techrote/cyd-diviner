#!/usr/bin/env python3
"""Non-destructive, byte-exact derived archive and compact publication proposal."""
from __future__ import annotations
import argparse
import collections
import datetime as dt
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tempfile
import urllib.parse
import zipfile

ARCHIVE_NAME = "DERIVED-ANALYSES.zip"


def sha(data): return hashlib.sha256(data).hexdigest()
def digest(path): return sha(path.read_bytes())
def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as f: f.write(json.dumps(data, indent=2) + "\n")
def git(root, *args, stdin=None):
    return subprocess.run(["git", *args], cwd=root, input=stdin, capture_output=True, check=False)
def git_paths(root, *args):
    r = git(root, *args)
    return set(r.stdout.decode().rstrip("\0").split("\0")) - {""} if r.returncode == 0 else set()


def select_roots(root):
    return sorted(d for d in (root / "evidence").iterdir() if d.is_dir() and (
        d.name.endswith(("-analysis", "-demod", "-envelope")) or "-analysis-v" in d.name
        or d.name.startswith(("sdr-signals-", "audio-offline-"))
        or d.name in ("host-kernels", "native-replay", "sdr-framed-stimuli", "sdr-metal-stimuli")))


def inspect_files(root, directories):
    files = {}
    for directory in directories:
        for path in sorted(directory.rglob("*")):
            if path.is_symlink(): raise ValueError("Source symlink requires explicit preservation review: " + str(path))
            if path.is_file():
                name = path.relative_to(root).as_posix()
                data = path.read_bytes()
                files[name] = {"bytes": len(data), "sha256": sha(data)}
    return files


def keep_live(name, root_name, tracked):
    """Original data are always archived, regardless of their live disposition."""
    path, relative = PurePosixPath(name), PurePosixPath(name).relative_to(root_name)
    if path.suffix.lower() == ".wav": return False
    if len(relative.parts) == 1: return True  # Preserve full JSON/summary/report/manifests byte-exact.
    if root_name.endswith(("/host-kernels", "/native-replay", "/sdr-framed-stimuli", "/sdr-metal-stimuli")):
        return name in tracked  # Existing compact replay/stimulus assets stay usable.
    if path.suffix.lower() in (".md", ".png", ".svg", ".pdf"): return True
    if len(relative.parts) != 1: return False
    if path.suffix.lower() == ".csv": return True
    if path.suffix.lower() == ".json" and "manifest" in path.name.lower(): return True
    return False


def original_manifest_audit(root, files):
    rows = []
    for name in files:
        p = root / name
        if p.suffix.lower() != ".json" or "manifest" not in p.name.lower(): continue
        try: value = json.loads(p.read_text(encoding="utf-8-sig"))
        except (ValueError, UnicodeError): continue
        outputs = value.get("outputs") if isinstance(value, dict) else None
        if not isinstance(outputs, dict): continue
        checked, mismatches, external = 0, [], []
        for relative, expected in outputs.items():
            if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected): continue
            target = (p.parent / relative).resolve()
            if not target.is_relative_to(root): external.append(relative); continue
            checked += 1
            if not target.is_file() or digest(target) != expected: mismatches.append(relative)
        rows.append({"manifest": name, "original_bytes_sha256": files[name]["sha256"],
                     "output_hashes_checked": checked, "mismatches": mismatches, "external_unchecked": external})
    return rows


def compact_summary(root, directory, files, archive):
    candidates = [directory / n for n in ("results.json", "audio-summary.json") if (directory / n).is_file()]
    value = json.loads(candidates[0].read_text(encoding="utf-8-sig")) if candidates else {}
    rows = value.get("runs", []) if isinstance(value, dict) else []
    if not isinstance(rows, list): rows = []
    name = directory.relative_to(root).as_posix()
    own = {p: m for p, m in files.items() if p.startswith(name + "/")}
    return {"schema": "cyd-perf-derived-publication-summary/1", "classification": "COMPACT_INDEX_OF_ARCHIVED_DERIVED_OUTPUTS",
        "original_directory": name, "archive": archive,
        "original_primary_member": candidates[0].relative_to(root).as_posix() if candidates else None,
        "original_primary_sha256": digest(candidates[0]) if candidates else None,
        "original_schema": value.get("schema"), "original_status": value.get("status"),
        "original_capture_status": value.get("capture_status"), "original_evidence_class": value.get("evidence_class"),
        "identities": value.get("identities"), "runs_count": len(rows),
        "run_status_counts": {key: dict(collections.Counter(str(r[key]) for r in rows if isinstance(r, dict) and key in r))
                              for key in ("status", "acquisition_status", "analysis_status", "demodulation_status")},
        "archived_original_files": len(own), "archived_original_bytes": sum(m["bytes"] for m in own.values()),
        "interpretation": "Status is copied, never promoted. Original manifests verify the complete extracted tree; compact publication hashes are separate. Detailed JSON, trials, waveforms and spectra are archive members."}


def package(root, archive, proposal, explicit_roots=None, guide_name="DERIVED-ANALYSES.md"):
    root, archive, proposal = root.resolve(), archive.resolve(), proposal.resolve()
    directories = explicit_roots or select_roots(root)
    if not directories or archive.exists() or proposal.exists(): raise ValueError("Nonempty roots and NEW archive/proposal paths required")
    if Path(guide_name).name != guide_name or not guide_name.endswith(".md"): raise ValueError("Guide must be one Markdown filename")
    if any(p.resolve().parent != root / "evidence" or p.name in ("physical", "hardware-access", "build-logs") for p in directories):
        raise ValueError("Only named derived evidence directories may be selected")
    names = [p.relative_to(root).as_posix() for p in directories]
    tracked = git_paths(root, "ls-files", "-z")
    staged = git_paths(root, "diff", "--cached", "--name-only", "-z")
    head_files = git_paths(root, "ls-tree", "-r", "--name-only", "-z", "HEAD")
    head = git(root, "rev-parse", "HEAD").stdout.decode().strip() or None
    files = inspect_files(root, directories)
    ignored = git(root, "check-ignore", "--stdin", "-z", stdin=("\0".join(files) + "\0").encode())
    ignored_set = set(ignored.stdout.decode().rstrip("\0").split("\0")) - {""}
    for name, record in files.items():
        owner = next(n for n in names if name.startswith(n + "/"))
        record.update(ignored_by_git=name in ignored_set, present_in_index=name in tracked,
                      staged_change=name in staged, present_in_HEAD=name in head_files,
                      live_disposition="KEEP_ORIGINAL" if keep_live(name, owner, tracked) else "ARCHIVE_ONLY_PROPOSED")
    audit = original_manifest_audit(root, files)
    script = Path(__file__).read_bytes()
    readme = ("# Complete derived-analysis snapshot\n\n"
        "Every selected on-disk file is retained byte-for-byte, including Git-ignored WAVs, PCM/IQ, trials, spectra and original manifests. "
        "These are derived analyses/generated models, not replacement raw acquisitions. Individual evidence classes/statuses remain unchanged.\n\n"
        "Extract into a NEW directory. Members evidence/<original-directory>/... restore each full original tree and its relative layout. "
        "Verify DERIVED-ANALYSES-MANIFEST.json before using original manifests; those manifests require the complete tree, not a compact/pruned publication. "
        "Raw physical captures and existing raw ZIPs remain separate.\n\n"
        "The packaging source is DERIVED-PACKAGING/build_derived_archives.py. Its --self-test is hardware-free; normal operation creates a NEW archive and proposal only, "
        "never deletes files, changes Git index or applies publication replacements. Rebuilding after a live tree has been pruned or reports rewritten cannot reconstruct the old original snapshot; use this archive instead.\n").encode()
    extra = {"DERIVED-PACKAGING/build_derived_archives.py": script, "DERIVED-ANALYSES-README.md": readme}
    manifest = {"schema": "cyd-perf-derived-archive/1", "classification": "DERIVED_ANALYSES_AND_GENERATED_MODELS",
        "source_checkout_HEAD": head, "selection": names, "filesystem_inventory_policy": "all regular files recursively; no extension/Git-ignore filtering; symlinks rejected",
        "original_manifest_audit": audit, "files": files,
        "packaging_files": {n: {"bytes": len(b), "sha256": sha(b)} for n, b in extra.items()}}
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, record in files.items():
            data = (root / name).read_bytes()
            if len(data) != record["bytes"] or sha(data) != record["sha256"]: raise ValueError("Source changed during packaging: " + name)
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED; info.create_system = 3; info.external_attr = 0o644 << 16
            z.writestr(info, data)
        for name, data in {**extra, "DERIVED-ANALYSES-MANIFEST.json": manifest_bytes}.items():
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED; info.create_system = 3; info.external_attr = 0o644 << 16
            z.writestr(info, data)
    # Verify archive membership, each payload and a fresh complete extraction.
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None or set(z.namelist()) != set(files) | set(extra) | {"DERIVED-ANALYSES-MANIFEST.json"}: raise ValueError("Archive membership/CRC verification failed")
        for name, record in {**files, **manifest["packaging_files"]}.items():
            data = z.read(name)
            if len(data) != record["bytes"] or sha(data) != record["sha256"]: raise ValueError("Archive payload verification failed: " + name)
        with tempfile.TemporaryDirectory(prefix="cyd-derived-verify-") as tmp:
            z.extractall(tmp)
            for name, record in {**files, **manifest["packaging_files"]}.items():
                if digest(Path(tmp) / name) != record["sha256"]: raise ValueError("Extracted payload differs: " + name)
    after = inspect_files(root, directories)
    if set(after) != set(files) or any(after[n]["sha256"] != files[n]["sha256"] for n in files): raise ValueError("Original tree changed during package verification")
    proposal.mkdir(parents=True)
    publication = proposal / "publication"
    replacements = []
    # Publication proposals change links only; originals remain byte-exact in ZIP.
    archive_only = {n for n, r in files.items() if r["live_disposition"] == "ARCHIVE_ONLY_PROPOSED"}
    rewrites, existing_missing = [], []
    pattern = re.compile(r"(!?\[[^\]]*\])\(([^\s)]+)\)")
    for path in sorted((root / "evidence").rglob("*.md")):
        relative = path.relative_to(root).as_posix()
        if relative.startswith(("evidence/physical/", "evidence/hardware-access/", "evidence/build-logs/", "evidence/derived-packaging/")): continue
        original = path.read_bytes()
        try: text = original.decode("utf-8-sig")
        except UnicodeError: continue
        def rewrite(match):
            label, href = match.groups()
            parsed = urllib.parse.urlsplit(href.strip("<>"))
            if parsed.scheme or not parsed.path: return match.group(0)
            target = (path.parent / urllib.parse.unquote(parsed.path)).resolve()
            if not target.is_relative_to(root): return match.group(0)
            name = target.relative_to(root).as_posix()
            if name in archive_only:
                owner = next(n for n in names if name.startswith(n + "/"))
                import os
                guide = Path(os.path.relpath(root / "evidence" / guide_name, path.parent)).as_posix()
                replacement = f"{label}({guide}#{PurePosixPath(owner).name})"
                rewrites.append({"source": relative, "original_href": href, "archive_member": name, "replacement": replacement})
                return replacement
            if not target.exists(): existing_missing.append({"source": relative, "href": href, "target": name})
            return match.group(0)
        updated = pattern.sub(rewrite, text)
        if updated != text:
            destination = publication / relative; destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(updated, encoding="utf-8", newline="\n")
            replacements.append({"path": relative, "original_sha256": sha(original), "replacement_sha256": digest(destination), "reason": "explicit archive-guide link in publication copy; unchanged original is preserved in archive when selected"})
    keep = sorted(n for n in files if n not in archive_only)
    plan = {"schema": "cyd-perf-derived-publication-plan/1", "archive": archive.name, "archive_sha256": digest(archive),
        "original_files": len(files), "keep_original_paths": keep, "archive_only_proposed_paths": sorted(archive_only),
        "index_removal_candidates": sorted(archive_only & tracked), "previous_HEAD_paths_among_candidates": sorted(archive_only & head_files),
        "publication_replacements": replacements, "link_rewrites": rewrites, "preexisting_missing_local_links": existing_missing,
        "no_changes_applied": "No originals removed/overwritten, no index change. Root must review/apply copied publication files and staging/removal explicitly."}
    dump(proposal / "publication-plan.json", plan)
    for filename, values in (("keep-original-paths.txt", keep), ("archive-only-proposed-paths.txt", sorted(archive_only)),
        ("git-index-removal-candidates.txt", plan["index_removal_candidates"])):
        (proposal / filename).write_text("\n".join(values) + "\n", encoding="utf-8")
    receipt = {"schema": "cyd-perf-derived-archive-receipt/1", "status": "VERIFIED_ARCHIVE_PUBLICATION_NOT_APPLIED",
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "archive": archive.name,
        "archive_sha256": digest(archive), "archive_bytes": archive.stat().st_size,
        "manifest_member": "DERIVED-ANALYSES-MANIFEST.json", "manifest_sha256": sha(manifest_bytes),
        "source_files": len(files), "source_bytes": sum(r["bytes"] for r in files.values()), "zip_members": len(files) + len(extra) + 1,
        "source_directories": names, "ignored_files_included": sum(r["ignored_by_git"] for r in files.values()),
        "WAV_files_included": sum(PurePosixPath(n).suffix.lower() == ".wav" for n in files),
        "byte_exact_original_manifests": len(audit), "original_manifest_output_mismatches": [r for r in audit if r["mismatches"]],
        "verification": {"source_snapshot_unchanged": True, "membership_and_member_hashes": True, "ZIP_CRC": True, "fresh_extraction_hashes": True,
            "Git_index_changed_by_packager": False, "raw_or_existing_ZIP_changed": False},
        "packager_sha256": sha(script), "proposal_plan_sha256": digest(proposal / "publication-plan.json"),
        "proposed_archive_only_files": len(archive_only), "proposed_index_removals": len(plan["index_removal_candidates"]),
        "proposed_publication_replacements": len(replacements), "archive_link_rewrites": len(rewrites),
        "preexisting_missing_local_links": existing_missing}
    dump(proposal / "receipt.json", receipt)
    return receipt, plan


def self_test():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp); directory = root / "evidence/fixture-analysis"; (directory / "nested").mkdir(parents=True)
        (directory / "results.json").write_bytes(b'{"schema":"FIXTURE_NOT_RF","status":"FAILED","runs":[]}\n')
        (directory / "nested/ignored.wav").write_bytes(bytes(range(256)))
        (directory / "summary.csv").write_bytes(b"case,status\nfixture,FAILED\n")
        (directory / "REPORT.md").write_bytes(b"[Details](results.json) [Audio](nested/ignored.wav)\n")
        expected = {n.relative_to(directory).as_posix(): digest(n) for n in directory.rglob("*") if n.is_file()}
        (directory / "manifest.json").write_text(json.dumps({"outputs": expected}), encoding="utf-8")
        before = inspect_files(root, [directory])
        receipt, plan = package(root, root / ARCHIVE_NAME, root / "proposal", [directory])
        assert receipt["WAV_files_included"] == 1 and not receipt["original_manifest_output_mismatches"]
        assert before == inspect_files(root, [directory]) and len(plan["link_rewrites"]) == 1
        assert json.loads((directory / "results.json").read_text())["status"] == "FAILED"
        assert "evidence/fixture-analysis/results.json" in plan["keep_original_paths"]
        with zipfile.ZipFile(root / ARCHIVE_NAME) as z: assert z.read("evidence/fixture-analysis/nested/ignored.wav") == bytes(range(256))
        try: package(root, root / ARCHIVE_NAME, root / "another", [directory]); raise AssertionError("Existing ZIP overwrite accepted")
        except ValueError: pass
    print("PASS: full bytes/WAV/manifests, extraction, failure status, links, source immutability and no overwrite")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path); parser.add_argument("--archive", type=Path); parser.add_argument("--proposal", type=Path)
    parser.add_argument("--roots-file", type=Path, help="Explicit JSON list of direct evidence child directory names; no discovery")
    parser.add_argument("--guide-name", default="DERIVED-ANALYSES.md")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test: self_test()
    else:
        if not all((args.root, args.archive, args.proposal)): parser.error("--root, --archive and --proposal required")
        selected = None
        if args.roots_file:
            entries = json.loads(args.roots_file.read_text(encoding="utf-8-sig"))
            if not isinstance(entries, list) or not entries or len(entries) != len(set(entries)):
                parser.error("--roots-file must be a nonempty unique directory-name JSON list")
            if any(not isinstance(n, str) or Path(n).name != n for n in entries): parser.error("Direct child names only")
            selected = [(args.root / "evidence" / n).resolve() for n in entries]
        receipt, plan = package(args.root, args.archive, args.proposal, selected, args.guide_name)
        print(json.dumps(receipt, indent=2))
