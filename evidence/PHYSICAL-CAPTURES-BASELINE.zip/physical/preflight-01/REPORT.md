# CYD performance evidence — preflight-01

Capture status: **CAPTURE COMPLETE**. Completed physical runs: **3/3**; pending or incomplete: **0**. Explicit NOT RUN workload classes: **0**.

This is a short preflight capture. Its observations do not establish the full mission envelope or a sustained stress result.

Board: CYD on COM21 (owner identified), ESP32-D0WD-V3 revision 3.1. Source [a4549f87cef05d19d9acf96d59ae95a2435ebb67](https://github.com/techrote/cyd-diviner/commit/a4549f87cef05d19d9acf96d59ae95a2435ebb67); profile `cyd-profile`; firmware SHA256 `fb35d75725b15ecd8b6aceb368492cf76ebaee85bbb4aeb50bd61311e229f15c`. Input results SHA256 `891fa31109edb0c8e6e51ef514755b3103e5fe2b82a88c66d00ff7e4a27ec2df`.

CPU 240 MHz, 2 cores; flash 4194304 bytes at 40000000 Hz; PSRAM 0 bytes. LCD SPI write/read 40000000/8000000 Hz; serial 533333 baud. SDK `v4.4.7-dirty`.

Fixed plan seed: `23063`. Ordinary requested warmup/window: 1000/3000 ms; default repetitions: 1. Per-case overrides remain in [results.json](results.json). Reset policy: `fresh_audio_DSP_state_each_entry_seeded_no_song_persistence`. Audio-window alignment: `real_setup_and_warmup_elapsed_not_sample_aligned`.

Saved display settings at initial inventory: theme 2, background style 1, gradient mode 1, canvas depth 16 bits. Orientation/backdrop commands then override the inventory values per workload. The exact palette, intensity table, setup acknowledgements and actual scene receipts are retained in JSON/raw logs.

## Interpretation

FPS is completed physical presentations divided by the target window, with the existing 33 ms frame cap. CPU percentages use tick-sampled current-task versus idle-task classification, not cycle-accurate task or interrupt accounting. Direct rendering interleaves CPU drawing and SPI transfer; its present duration cannot be separated into independent raster and bus costs. Histogram percentiles below are **upper bounds**. Human tables tighten each bound to `min(raw powers-of-two bucket upper, exact observed maximum)`; a capped bound equal to the maximum is still a bound, not an exact percentile. Raw target records and summary CSVs retain the original bucket upper bounds unchanged. Maxima are exact observed durations. A p99 is omitted below 100 observations. Percentiles and maxima describe these finite runs; they are not deadline guarantees.

Only repetitions with matching requested settings, duration, warmup, instrumentation and actual scene/allocation receipts are pooled. A scope suffix identifies variants if the same workload name has differing receipts. Independent maxima or percentiles must not be added as if they came from the same audio block.

Instrumentation A/B scope: `histogram_insertion_only_timestamps_hooks_counts_retained`. The enable switch controls histogram insertion while timestamps, hooks, frame/block counts and retained sampling remain. The on/off rows therefore measure that insertion change only. Total overhead relative to an ordinary firmware binary is not established by this switch. Disabled histograms give unavailable timing distributions rather than zero-duration work.

## Physical scene envelopes

| Workload | reps | presents | FPS | interval p95≤/max ms | present p95≤/max ms | CPU0/1 % | min free/largest B |
| --- | --- | --- | --- | --- | --- | --- | --- |
| menu/landscape/theme | 1 | 88 | 29.33 | 35.08/35.08 | 28.14/28.14 | 6.2/86.6 | 99872/47092 |
| visions/landscape/fullscreen/gate-trails | 1 | 68 | 22.67 | 45.16/45.16 | 42.41/42.41 | 6.9/97.4 | 99408/47092 |
| audio/drone/local-and-pcm | 1 | 89 | 29.67 | 34.58/34.58 | 25.40/25.40 | 12.5/86.9 | 83004/47092 |

Free/largest heap values are minima of retained samples in each scope, not continuous allocation traces. Boot-wide heap low water and task-lifetime stack low water are separate fields in the summary; they cannot identify a per-scene leak alone.

## Touchscreen polling and control dispatch

| Selected scope | reps | XPT polls n | observed polls/s | poll p95≤/max µs | dispatch n | dispatch p95≤/max µs |
| --- | --- | --- | --- | --- | --- | --- |
| menu/landscape/theme | 1 | 88 | 29.33 | 158/158 | 88 | 5/5 |
| visions/landscape/fullscreen/gate-trails | 1 | 68 | 22.67 | 308/308 | 68 | 20/20 |

The selection includes the menu baseline, the slowest captured fullscreen scope per orientation and scripted-touch cases. Polling rate is the measured `touch_poll_us` observation count divided by target steady-window elapsed time: actual XPT2046 `getPoint` calls, including polls with no contact. It is an average call rate, not a guaranteed polling interval or physical touch response rate. `touch_dispatch_us` counts control-dispatch invocations, including no-contact samples and synthetic input; it does not count distinct physical touches or generated application keys. Scripted replay is firmware injection. No controlled physical contact stimulus, contact-to-photon acquisition or physical latency distribution was measured.

## Audio scheduling

Configured audio: 24000 Hz, 128 samples/block (5333.333 µs nominal block period). Audio task core/priority 0/5; PCM writer core/priority 1/2. I2S inventory: 4 DMA buffers × 128 frames, 2 slots, DAC GPIO 26.

| Workload | callback n | callback p95≤/max µs | lock max µs | mix max µs | enqueue p95≤/max µs | period p99≤/max µs | late/write/short |
| --- | --- | --- | --- | --- | --- | --- | --- |
| menu/landscape/theme | 562 | 2/2 | 4 | 23 | 5232/5232 | 5346/5346 | 0/0/0 |
| visions/landscape/fullscreen/gate-trails | 562 | 216/216 | 3 | 29 | 5026/5026 | 5334/5334 | 0/0/0 |
| audio/drone/local-and-pcm | 562 | 498/498 | 4 | 22 | 4738/4738 | 5337/5337 | 0/0/0 |

The table includes explicit audio/combined/stress workloads and the scopes with the largest observed callback, cadence, lock or enqueue tails. Enqueue is the duration of blocking `i2s_write`, including waiting for DMA capacity. It is not an isolated compute cost. Late-period counters are inferred scheduling events. DMA underruns and analog output continuity are **unknown** without an appropriate detector/acquisition fixture. The complete lock, callback, overlay, mix, enqueue and cadence distributions are in [summary-metrics.csv](summary-metrics.csv).

## USB PCM integrity

| Run | Workload | valid | CRC | missing | duplicate | backward | discarded/tail B |
| --- | --- | --- | --- | --- | --- | --- | --- |
| r003_1 | audio/drone/local-and-pcm | 797 | 0 | 0 | 0 | 0 | 0/0 |

PCM receive windows include warmup, the steady target window, a 250 ms guard and stop-tail draining. Target counters cover the steady target window only. Missing sequence numbers can originate in a producer queue or transport; compare target queue/drop records before attribution. Loss before the first received sequence and after the last frame is unknown. Host arrival timing includes UART/OS buffering and cannot establish target audio cadence or DMA underruns. Raw per-run PCM binaries can be replayed with `capture.py decode-pcm`.

## Sustained CPU load and temperature

NOT RUN / no completed observations in this capture.

Recorded sensor method: `ESP32_ROM_raw_uncalibrated`. The approved primary a4549f8 image's legacy tag says ROM, while its linked implementation resolves through SDK `librtc.a` / `rtc_analog.o`; the tag does not establish a mask-ROM implementation. The sensor API is undocumented and its temperature accuracy is unsupported. Raw readings are uncalibrated indications. The reported °C values are the firmware's conversion, not independently calibrated die temperature. Ambient temperature was NOT MEASURED. Retained intervals, raw ticks and all sensor samples are available in [samples.csv](samples.csv). The confirmation predicate requires a completed ≥360-second window, ≥360 seconds of retained sample span, valid CPU hooks and ≥95% weighted busy time on both cores.

Across this capture, **6** retained in-window samples and outside-kernel/SPI snapshots span raw sensor codes **129–130**. These indications show the recorded trend without supplying an accuracy or calibration claim.

## SPI and portable kernels

NOT RUN / no completed observations in this capture.

SPI uses precomputed RGB565 eight-row stripes, includes commands and completion waits, and excludes artwork generation. It measures this transfer path, not an abstract SPI clock-rate ceiling.

NOT RUN / no completed observations in this capture.

Kernel timings pool exact chronological samples and include RTOS preemption. Output inspection is excluded. Working bytes describe kernel state; they are not the bytes that a remote node would need per request. The same seed and checksum checks support reproduction, while float/fixed-point precision comparisons remain separate validation evidence. Physical S3/C3 comparative execution is NOT RUN unless separately evidenced; a successful target build is not a hardware measurement.

## Actual scene and allocation receipts

| Workload | scope | actual configuration before measurement |
| --- | --- | --- |
| visions/landscape/fullscreen/gate-trails | 234a26e96244 | actual_base_effect=gate, actual_layered=True, history_requested=True, history_ready=True, history_format=LUT8, history_payload_bytes=27840, tunnel_allocated=True, tunnel_payload_bytes=13920, fire_allocated=False, fire_payload_bytes=0, native_fullscreen_at_receipt=False |
| audio/drone/local-and-pcm | 820b3ab27db8 | scene=drone, seed=23063, reset=fresh_DSP_state_each_entry, song_persistence=False, root_midi=38, scale=0, voices=5, brightness=0.45, drift=0.5, wind=True, bells=True, delay_samples=4096, delay_allocated=True |

Visions receipts are emitted after configuration and before the next frame. For native fullscreen trails the implementation uses bounded geometric paths and releases pixel history/tunnel on its first fullscreen frame; receipt-time allocated bytes must not be presented as measured fullscreen history occupancy. Sampled heap provides the in-window evidence. These paths are not numerically identical rendering kernels.

## Wireless scope

Radio rows measure isolated controller initialization and its effect on local scenes. They perform no peer discovery, association or traffic. No measured goodput, RTT, jitter/loss under traffic, or Wi-Fi/BLE/ESP-NOW coexistence envelope is established by these rows.

NOT RUN / no completed observations in this capture.

## I2S driver event capability

Driver event queue capability reported: `UNKNOWN / not exposed in this image`. No direct I2S event records occur in this capture. TX_Q_OVF and DMA_ERROR counts are unknown; the primary image's write-error/short-write counters and inferred late periods do not substitute for them. A supplementary events image must retain its own source/firmware identity and evidence folder.

## Evidence-based recommendations

* Use scene-specific display budgets: the lowest completed cadence among the captured ordinary scopes is **22.67 FPS** for `visions/landscape/fullscreen/gate-trails` across 1 repetitions. Use the measured tail/maximum durations and actual path when choosing VIBEWARE visual complexity; do not apply the menu rate to layered fullscreen effects.
* The largest observed main audio callback is **498 µs** in `audio/drone/local-and-pcm` (n=562, nominal block period 5333.333 µs). Keep callback, lock, overlay, mix and blocking enqueue as separate budgets; verify correlated per-block deadlines and analog continuity before claiming an underrun-free audio envelope.
* Offload break-even requires `local compute > remote compute + measured RTT + (input bytes + output bytes) / measured goodput` in consistent units. Measure input/state serialization, link tails/loss and remote service time on each candidate peer. No numeric minimum useful ratio can be established from controller-init-only radio tests.
* Reserve memory using the observed free/largest-block minima and allocation receipts for the intended combination of effects. Saved-palette gradients, history format, fullscreen path and radio initialization are workload settings, not incidental details. Repeat matching scene transitions and long sessions before diagnosing a leak or guaranteeing a memory margin.

## Missing evidence and reproduction

NOT RUN / no completed observations in this capture.

Current unfinished planned repetitions: 0. Missing observations stay absent rather than receiving theoretical estimates.

Reproduce with the captured plan, identified board, exact firmware digest and matching source/toolchain receipts. The harness never flashes. Owner authorization, private backup verification and the flash receipt are separate evidence. The on-board identity does not independently attest the firmware binary digest; preserve the flash/build chain.

```powershell
python tools/perf/capture.py analyze evidence/physical/preflight-01/results.json
python tools/perf/summarize.py evidence/physical/preflight-01/results.json
python tools/perf/report.py evidence/physical/preflight-01/results.json --label preflight-01
```

Artifacts: [results.json](results.json), [raw target JSONL](target.jsonl), [raw serial bytes](serial-rx.bin), [timestamped serial events](serial-events.jsonl), [metrics.csv](metrics.csv), [samples.csv](samples.csv), [summary.json](summary.json), [summary scenes](summary-scenes.csv), [summary metrics](summary-metrics.csv), [summary kernels](summary-kernels.csv), [artifact checksums](artifact-hashes.json).

## Plots

![audio-tails](figures/audio-tails.png)

![fps-audio](figures/fps-audio.png)

![fps-scenes](figures/fps-scenes.png)
