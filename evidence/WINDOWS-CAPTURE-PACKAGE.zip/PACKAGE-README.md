# Windows capture, analysis and reproducible-source package

Source/tools reference: e4dec3f0bc3212854dafe20513a6acab44eff6bd. The source-backed members match this clean Git snapshot. Campaign plans and generated stimuli are separately hashed checkout snapshots identified by kind. PACKAGE-MANIFEST.json hashes every other member; the external receipt hashes the complete ZIP.

This package contains host tools, schemas, plans, tests, portable model sources and complete headless SDR-metal SDK project source/provenance. Plaintext partitions.csv files are SDK build configuration only. No compiled app, bootloader, partition binary/data/readback, executable, owner identity manifest, hotspot credentials, private configuration or physical capture log/result is included. Extraction never authorizes flashing or RF.

Preserve directories and work at the extracted root. Python3.12 and pyserial are needed for capture; analysis/plots optionally need the second requirements file:
~~~powershell
python -m pip install -r tools/perf/requirements.txt
python -m pip install -r tools/perf/analysis-requirements.txt
python -m unittest discover -s tools/perf -p 'test_*.py'
~~~

Read tools/perf/README.md, COLOR.md, AUDIO-MVP.md, AUDIO_MVP.md, LINK.md, SDR.md, SDR-METAL.md, SDR-METAL-DUAL.md and SDR-METAL-ENVELOPE.md before selecting an experiment. Ports/images must be owner-identified with separate verified flash receipts. RF capture additionally requires explicit operator authorization. Existing failed/incomplete evidence must retain its status.

## Portable models

At the extracted root in WSL with GNU C++17 installed:
~~~sh
mkdir -p .pio
g++ -std=c++17 -O1 -g -Wall -Wextra -Werror -DGRIM_PERF_AUDIO_CORE_STANDALONE=1 -I src src/perf_audio_core.cpp tools/perf/test_audio_core.cpp -o .pio/perf-audio-core-test
g++ -std=c++17 -O2 -g -Wall -Wextra -Werror experiments/sdr/protocol.cpp experiments/sdr/test_protocol.cpp -o .pio/sdr-model-test-metal
g++ -std=c++17 -O2 -Wall -Wextra -Werror -I src src/perf_kernels.cpp tools/perf/kernels_host.cpp -o .pio/perf-kernels-host
~~~
Optional -fsanitize=address,undefined -fno-omit-frame-pointer enables sanitizer checks. Use --wsl from PowerShell with audio_mvp_simulate.py and sdr_analyze.py to invoke the ELF models. The final SDR source retains the separately validated low-sample-per-symbol receiver and expands only emitter baud metadata to positive integers through 240MHz. Run .pio/sdr-model-test-metal, then .pio/sdr-model-test-metal --low-sps-tests, and python3 experiments/sdr/test_emit_cli.py --binary .pio/sdr-model-test-metal --output .pio/emit-validation from WSL to reproduce current host checks. Earlier binaries/manifests retain earlier immutable validation cohorts; protocol-manifest-metal.json pins current sources and new validation receipts. Accepted stimulus baud does not prove physical RF performance. kernels_host timing is HOST_REPLAY, never ESP hardware performance. validate_kernels.py expects Git provenance in a full checkout; direct compiler commands work in this package.

Continuous raw-PDM impairment is OFFLINE_MODEL. Optional packetized PDM remains ESP-NOW and does not fulfill the proprietary raw SDR arm. Greenfield SDR framing/TX/IQ demodulation is a separate experiment. Acquisition, RF envelope, valid decoded headers/payload, digital reconstruction and analog output are distinct evidence. Host demodulation does not establish onboard real-time DAC output or synchronized latency. Generated stimuli/WAVs under evidence/sdr-framed-stimuli are source inputs, not RF measurements.

## Pinned SDK build-only recipes

The experimental metal projects require ESP-IDF5.5.5 commit b774170ff46c393eeb5e495ea37936038d3f4f4f and its installed official target tools. Read each experiments/sdr-metal project README and provenance/license first. RX includes GPL-3.0 ESPARGOS/esp-sdr helper source and its complete license/provenance; source files retain their own notices.

For hardware-image builds, use a full repository Git checkout at e4dec3f0bc3212854dafe20513a6acab44eff6bd so CMake can embed meaningful source identity; this ZIP deliberately contains no .git metadata. The included source permits inspection and byte verification. Do not initialize a replacement repository and claim it is the recorded source revision. Obtain/install the pinned SDK and official tools separately; neither SDK binaries nor newly built images are provided or authorized by this package.

From the repository root in PowerShell, set task-specific IdFRoot/IdfToolsRoot paths to the installed SDK/tools. Activate its export.ps1, verify git -C <IdfRoot> rev-parse HEAD equals the pin, then build only:
~~~powershell
$env:IDF_TOOLS_PATH = $IdfToolsRoot
. (Join-Path $IdfRoot 'export.ps1')
python (Join-Path $IdfRoot 'tools/idf.py') -C experiments/sdr-metal/tx -B .pio/sdr-metal-tx -D IDF_TARGET=esp32 build
python (Join-Path $IdfRoot 'tools/idf.py') -C experiments/sdr-metal/tx-s3 -B .pio/sdr-metal-tx-s3 -D IDF_TARGET=esp32s3 build
./experiments/sdr-metal/rx/build.ps1 -IdfRoot $IdfRoot -IdfToolsRoot $IdfToolsRoot -BuildDirectory .pio/sdr-metal-rx
~~~
These commands build without opening COM ports or flashing. A rebuild can have a new image digest/source stamp; preserve its own receipt, review partition compatibility and obtain exact-image approval before writing hardware. NVS/calibration persistence is disabled by these experiments, not by an erase operation.

The RX aperture is reserved by linker assertions and captures separate finite bursts. Its nominal16/40/80MHz settings are not independently calibrated clock measurements. No-export capture timing, deferred USB readout, software MMIO writes and actual RF observations remain separate scopes. See SDR-METAL.md for source/CRC/canary/restoration/ownership/temperature/IRQ proofs and their limits.
