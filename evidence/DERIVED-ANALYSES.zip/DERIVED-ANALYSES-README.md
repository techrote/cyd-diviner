# Complete derived-analysis snapshot

Every selected on-disk file is retained byte-for-byte, including Git-ignored WAVs, PCM/IQ, trials, spectra and original manifests. These are derived analyses/generated models, not replacement raw acquisitions. Individual evidence classes/statuses remain unchanged.

Extract into a NEW directory. Members evidence/<original-directory>/... restore each full original tree and its relative layout. Verify DERIVED-ANALYSES-MANIFEST.json before using original manifests; those manifests require the complete tree, not a compact/pruned publication. Raw physical captures and existing raw ZIPs remain separate.

The packaging source is DERIVED-PACKAGING/build_derived_archives.py. Its --self-test is hardware-free; normal operation creates a NEW archive and proposal only, never deletes files, changes Git index or applies publication replacements. Rebuilding after a live tree has been pruned or reports rewritten cannot reconstruct the old original snapshot; use this archive instead.
