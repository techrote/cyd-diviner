Immutable SDR-metal fast/source-integrity app snapshot

Source: e8b4c8a9f5073db86706f9cebbaefb0476549ef6
SDK: b774170ff46c393eeb5e495ea37936038d3f4f4f
Frozen review SHA256: 3498d187b5a1d858eecc5ef1d056532eb4d19c53a4e456613f330bcde585f3f2

Exact app-only images, debug/configuration inputs and source; no production promotion. Root reported owner authorization for this exact review and78 finite tests; actual flashing/capture results are separate receipts. Packaging performed no serial, RF or firmware write.

Changes: explicit bare-RX receive enable; fast IRQ-enabled rational TX pacing retaining source order; checked USB/source CRCs. Requested rates through240M are settings, not attained-rate claims. Plans:3 smoke+42 rate+21 framed+12 compatibility windows, requested1s each with2s payload limit. Software timing/CRC is not independent RF-edge, throughput or one-way-latency proof.

Corresponding-source.zip includes exact Git source and repository/GPL licenses and provenance. External ESP-IDF is pinned. No bootloader, partition-table image, NVS, private backup, credential, RF permit, raw capture or flashing automation is bundled. Source partition CSVs are build configuration only.
